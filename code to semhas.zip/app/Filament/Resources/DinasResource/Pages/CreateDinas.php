<?php

namespace App\Filament\Resources\DinasResource\Pages;

use App\Filament\Resources\DinasResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDinas extends CreateRecord
{
    protected static string $resource = DinasResource::class;
}
