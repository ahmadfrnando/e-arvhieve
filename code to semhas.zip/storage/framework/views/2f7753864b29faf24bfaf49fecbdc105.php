<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Surat Masuk</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        h1, h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            font-size: 10px;
        }
    </style>
</head>
<body>
    <h1>Laporan Surat Masuk</h1>
    <h2>Total Surat : <?php echo e($suratMasuk->count()); ?></h2>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>No. Surat</th>
                <th>Subjek</th>
                <th>Pengirim</th>
                <th>Status</th>
                <th>Tanggal Masuk</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $suratMasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($surat->nosurat); ?></td>
                <td><?php echo e($surat->subjek); ?></td>
                <td><?php echo e($surat->pengirim); ?></td>
                <td><?php echo e($surat->status); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($surat->created_at)->locale('id')->translatedFormat('l, d F Y')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="footer">
        Dinas Ketenagakerjaan Provinsi Sumatera Utara &copy; <?php echo e(date('Y')); ?>

    </div>
</body>
</html>
<?php /**PATH D:\application\disnaker\resources\views/suratmasukpdf.blade.php ENDPATH**/ ?>